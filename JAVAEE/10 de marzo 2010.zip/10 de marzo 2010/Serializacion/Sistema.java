public class Sistema{
	public static void main(String args[]){
		/*Contacto contacto = new Contacto();
		contacto.setNombre("Jorge");
		contacto.setApellido("Perez");*/
		Serializadora serializadora = new Serializadora();
		//serializadora.serializar(contacto, "contacto.obj");
		Contacto recuperado = (Contacto) serializadora.desserializar("contacto.obj");
		System.out.println(recuperado.getNombre() + " " + recuperado.getApellido());
	}
}
