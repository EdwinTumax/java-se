import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.Serializable;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
public class Serializadora{
	public void serializar(Serializable objeto, String nombreArchivo){
		try{
			ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(nombreArchivo));
			salida.writeObject(objeto);
			salida.close();
		}catch(IOException ioe){
			System.out.println("Error al serializar: " + ioe.getMessage());
		}
	}

	public Object desserializar(String nombreArchivo){
		Object objeto = null;
		try{
			ObjectInputStream  entrada = new ObjectInputStream(new FileInputStream(nombreArchivo));
			objeto = entrada.readObject();
		}catch(Exception ioe){
			System.out.println("Error al desserializar: " + ioe.getMessage());
		}
		return objeto;
	}
}
