package org.raydelto.agenda.servlets;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.ServletException;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import java.io.PrintWriter;
import org.raydelto.agenda.beans.Usuario;
import javax.servlet.http.HttpSession;
public class ServletBienvenida extends HttpServlet{
	public void doPost(HttpServletRequest peticion, HttpServletResponse respuesta) 
		throws IOException,ServletException{
		RequestDispatcher despachador = null;
		if(peticion.getParameter("usuario").equals("edwin") &&
			peticion.getParameter("clave").equals("888")){	
			Usuario usuario = new Usuario();
			usuario.setNombre("Edwin");
			usuario.setApellido("Tumax");
			HttpSession sesion = peticion.getSession();
			sesion.setAttribute("usuario", usuario);			
			String correoAdministrador = getServletConfig().getInitParameter("correoAdministrador");
			peticion.setAttribute("correoAdministrador", correoAdministrador);			
			System.out.println("El correo es:  " + correoAdministrador);
				
			despachador = peticion.getRequestDispatcher("bienvenido.jsp");
		}else{
			despachador = peticion.getRequestDispatcher("denegado.jsp");
		}
		despachador.forward(peticion, respuesta);		
	}	
}
